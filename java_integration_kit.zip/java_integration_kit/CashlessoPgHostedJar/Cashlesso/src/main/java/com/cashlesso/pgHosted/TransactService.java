package com.cashlesso.pgHosted;

import java.util.HashMap;
import java.util.Map;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;
 

public class TransactService {

	 
	public static Map<String, String>  ServiceExecute(String URL, Map<String,String> sortedMap) {
		JSONObject json = new JSONObject();
		Map<String, String> resMap = new HashMap<String, String>();
		String responseBody="";
		try {
		for (Map.Entry<String, String> entry : sortedMap.entrySet()) {
			String k = entry.getKey();
			String v = entry.getValue();
			json.putOnce(k, v);
		}
		
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost requests = new HttpPost(URL);
		StringEntity paramas = new StringEntity(json.toString());
		requests.addHeader("Content-type", "application/json");
		requests.setEntity(paramas);
		CloseableHttpResponse resp = httpClient.execute(requests);
		 responseBody = EntityUtils.toString(resp.getEntity());
		 final ObjectMapper mapper = new ObjectMapper();
		 final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
			resMap = mapper.readValue(responseBody, type);
		
	}catch (Exception e) {
		
		 System.out.println(e);
	}
		return resMap;
	}
}
	 
 

