package com.cashlesso.pgHosted;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.EmptyStackException;
import java.util.Stack;
import java.util.logging.Logger;

public class MessageDigestProvider {
	private final static Logger LOGGER = Logger.getLogger(Hasher.class.getName());
	private static Stack<MessageDigest> stack = new Stack<MessageDigest>();

	public static MessageDigest provide() {
		MessageDigest digest = null;
		try{
			digest = stack.pop();
		} catch (EmptyStackException emptyStackException){
			try {
				digest = MessageDigest.getInstance("SHA-256");
			} catch (NoSuchAlgorithmException noSuchAlgorithmException) {
				LOGGER.info("noSuchAlgorithmException");
			}
		}
		
		return digest;
	}
	
	public static void consume(MessageDigest digest){
		stack.push(digest);
	}
}
