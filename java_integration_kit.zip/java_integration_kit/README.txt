=== Plugin Name ===
CASHLESSO JSP PG HOSTED KIT 

=== Description of Cashlesso Payment Gateway ===
Its Allow you to use Cashlesso payment gateway work with the Jsp . It is secure to pay online via cashlesso and it is strongly recommended for Indian Payments.


=== Integration of CASHLESSO PG HOSTED JSP Kit ===
1. We are providing the "Cashlesso-java-PgHostedKit-jar-with-dependencies.jar" and 8 JSP files(index.jsp,cashlesso.jsp,response.jsp,   error.jsp,refund.jsp,RefundForm.jsp,statusEnquiry.jsp,StatusEnquiryForm.jsp)
2. First Add the "Cashlesso-java-PgHostedKit-jar-with-dependencies.jar" into the following locaiton --> src/webapp/Web-INF/lib and also add this jar as external jar. 
3. After that add the mentioned jsp files in your project. 



=== Docs & Support ===
For Support and Issues with Cashlesso PG HOSTED JSP Kit? mail us on [rohit@cashlesso.com].



=== Configuration ===
1. In cashlesso.jsp, refund.jsp, response.jsp, statusEnquiry.jsp add SALT given by cashlesso.

2. In index.jsp --> you need to cross check all the input fields you mentioned correct or not. PAY_ID and other details. Return Url as like this --> your server url along with response.jsp .Currently, We are using the following return url --> http://localhost:8080/CashlessoJspKit/response.jsp, you need to change according to your server.  

Now you can make your payment securely through CASHLESSO by selecting it as the Payment Method at the Checkout stage.

Thank You
CASHLESSO.
